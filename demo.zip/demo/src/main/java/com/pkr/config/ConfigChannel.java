package com.pkr.config;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.SubscribableChannel;

public interface ConfigChannel {

    String USER_DETAILS_OUTPUT = "user-details-output";
    String USER_DETAILS_INPUT = "user-details-input";
    String USER_LIST_OUTPUT = "user-list-output";
    String USER_LIST_INPUT = "user-list-input";

    @Output(USER_DETAILS_OUTPUT)
    SubscribableChannel userDetailsOutput();

    @Input(USER_DETAILS_INPUT)
    SubscribableChannel userDetailsInput();

    @Output(USER_LIST_OUTPUT)
    SubscribableChannel userListOutput();

    @Input(USER_LIST_INPUT)
    SubscribableChannel userListInput();
}
