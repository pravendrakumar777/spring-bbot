package com.pkr.repository;

import com.pkr.dto.UserDTO;
import com.pkr.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query(value = "SELECT * FROM user_details WHERE date BETWEEN :fromDate AND :toDate", nativeQuery = true)
    List<User> findUsersByDateRange(@Param("fromDate") Timestamp fromDate, @Param("toDate") Timestamp toDate);

    //List<UserDTO> findByStatus(String status);
    List<User> findByStatus(String status);
}
