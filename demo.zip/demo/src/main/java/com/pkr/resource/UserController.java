package com.pkr.resource;

import com.pkr.dto.UserDTO;
import com.pkr.model.User;
import com.pkr.payload.UserRequest;
import com.pkr.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UserService userService;

    @GetMapping("/create-user")
    public String createUserPage() {
        return "createUser";
    }

    @PostMapping("/users")
    public ResponseEntity<User> createUser(@RequestBody UserRequest userRequest) {
        User result = userService.saveUser(userRequest);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/fetch-all-users")
    public String fetchAllUsersPage(Model model) {
        List<UserDTO> users = userService.fetchUsers();
        model.addAttribute("users", users);
        return "fetchAllUsers";
    }

    @GetMapping("/users/fetch-all")
    public ResponseEntity<List<UserDTO>> fetchAllUsers() {
        List<UserDTO> result = userService.fetchUsers();
        return ResponseEntity.ok(result);
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<User> findUserById(@PathVariable Long id) {
        User user = userService.findUserById(id);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/update-user")
    public String updateUserPage() {
        return "updateUser";
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody UserRequest userRequest) {
        User updatedUser = userService.updateUser(id, userRequest);
        if (updatedUser != null) {
            return ResponseEntity.ok(updatedUser);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/delete-user")
    public String deleteUserPage() {
        return "deleteUser";
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        boolean isDeleted = userService.deleteUser(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/users/status")
    public String fetchUsersByStatus(@RequestParam(required = false) String status, Model model) {
        List<UserDTO> users = userService.fetchUsers();
        model.addAttribute("users", users);
        return "userManagement";
    }

    @GetMapping("/users/enabled")
    public String fetchEnabledUsers(Model model) {
        List<UserDTO> users = userService.fetchEnabledUsers();
        model.addAttribute("users", users);
        return "enabledUsers";
    }


    @GetMapping("/users/disabled")
    public String fetchDisabledUsers(Model model) {
        List<UserDTO> users = userService.fetchDisabledUsers();
        model.addAttribute("users", users);
        return "disabledUsers";
    }
}
