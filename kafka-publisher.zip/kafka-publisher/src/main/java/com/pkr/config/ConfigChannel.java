package com.pkr.config;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.SubscribableChannel;

public interface ConfigChannel {

    String USER_DETAILS_OUTPUT = "user-details-output";
    String USER_LIST_OUTPUT = "user-list-output";

    @Output(USER_DETAILS_OUTPUT)
    SubscribableChannel userDetailsOutput();

    @Output(USER_LIST_OUTPUT)
    SubscribableChannel userListOutput();
}
