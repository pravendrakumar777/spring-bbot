package com.pkr.service;

import com.pkr.dto.UserDTO;
import com.pkr.dto.UserDateDTO;
import com.pkr.model.User;
import com.pkr.payload.UserRequest;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public interface UserService {

    User saveUser(UserRequest userRequest);
    List<User> fetchUsersByDateRange(String fromDate, String toDate);
    List<UserDTO> fetchUsers();
    User findUserById(Long id);
    User updateUser(Long id, UserRequest userRequest);
    boolean deleteUser(Long id);
    List<UserDTO> fetchEnabledUsers();
    List<UserDTO> fetchDisabledUsers();
    Map<String, Long> getUserCountsByStatus();
    List<UserDateDTO> getUsersByDateRange(Timestamp fromDate, Timestamp toDate);
    List<User> searchUsers(String name, String email, String mobile, String status, String gender);
}
