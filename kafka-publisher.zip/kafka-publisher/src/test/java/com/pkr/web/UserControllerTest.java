package com.pkr.web;

import com.pkr.resource.UserResource;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest(UserResource.class)
public class UserControllerTest {

}
