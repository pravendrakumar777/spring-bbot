package com.rnsoftech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaSubscriberApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaSubscriberApplication.class, args);
		// Swagger UI = http://localhost:8084/swagger-ui.html

		// MVC UI = http://localhost:8084/create-user
		// All operation can on single url
	}
}
