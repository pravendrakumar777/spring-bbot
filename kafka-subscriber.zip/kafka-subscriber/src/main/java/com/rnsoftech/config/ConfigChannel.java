package com.rnsoftech.config;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface ConfigChannel {

    String USER_DETAILS_INPUT = "user-details-input";
    String USER_LIST_INPUT = "user-list-input";

    @Input(USER_DETAILS_INPUT)
    SubscribableChannel userDetailsInput();

    @Input(USER_LIST_INPUT)
    SubscribableChannel userListInput();
}
