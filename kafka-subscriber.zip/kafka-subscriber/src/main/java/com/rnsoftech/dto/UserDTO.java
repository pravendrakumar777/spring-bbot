package com.rnsoftech.dto;

public class UserDTO {
    private Long id;
    private String name;
    private String email;
    private String createdDate;
    private String mobile;
    private String modifiedDate;
    private String status;
    private String gender;

    public UserDTO(){}

    public UserDTO(Long id, String name, String email, String createdDate, String mobile, String modifiedDate, String status, String gender) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.createdDate = createdDate;
        this.mobile = mobile;
        this.modifiedDate = modifiedDate;
        this.status = status;
        this.gender = gender;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", mobile='" + mobile + '\'' +
                ", modifiedDate='" + modifiedDate + '\'' +
                ", status='" + status + '\'' +
                ", gender='" + gender + '\'' +
                '}';
    }
}
