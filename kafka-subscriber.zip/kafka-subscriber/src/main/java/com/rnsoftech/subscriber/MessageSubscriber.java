package com.rnsoftech.subscriber;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rnsoftech.config.ConfigChannel;
import com.rnsoftech.model.User;
import com.rnsoftech.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Component
public class MessageSubscriber {

    private static final Logger log = LoggerFactory.getLogger(MessageSubscriber.class);
    private final UserRepository userRepository;

    public MessageSubscriber(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @ServiceActivator(inputChannel = ConfigChannel.USER_DETAILS_INPUT)
    public void subscribeUser(User user) {
        log.info("SERVICE REQUEST TO SUBSCRIBE USER : {}", user);
        userRepository.save(user);
    }

    @ServiceActivator(inputChannel = ConfigChannel.USER_LIST_INPUT)
    public void subscribeUsers(byte[] userList) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            String userListString = new String(userList, StandardCharsets.UTF_8);
            log.info("SERVICE REQUEST TO SUBSCRIBE USER LIST : {}", userListString);

            JsonNode jsonNode = objectMapper.readTree(userList);

            if (jsonNode.isArray()) {
                List<User> users = objectMapper.readValue(userList, new TypeReference<List<User>>() {});

                for (User user : users) {
                    try {
                        userRepository.save(user);
                        log.info("User saved successfully: ID {}", user.getId());
                    } catch (Exception ex) {
                        log.error("Error saving user {}: {}", user.getId(), ex.getMessage());
                    }
                }
            } else if (jsonNode.isObject()) {
                User user = objectMapper.readValue(userList, User.class);
                userRepository.save(user);
                log.info("Single user saved successfully: ID {}", user.getId());
            } else {
                log.error("Unexpected JSON format: {}", userListString);
            }
        } catch (IOException ex) {
            log.error("Failed to deserialize user list: {}", ex.getMessage());
        }
    }
}
