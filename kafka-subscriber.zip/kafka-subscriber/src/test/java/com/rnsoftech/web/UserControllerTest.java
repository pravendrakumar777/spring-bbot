package com.rnsoftech.web;

import com.rnsoftech.resource.UserResource;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest(UserResource.class)
public class UserControllerTest {

}
